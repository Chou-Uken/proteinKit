# biofkit
Biofkit is now containing only one module with one package which can deal with pdb file (extract sequence, atom information and so on) very easily. 

## How to Install
### Conda
```console
conda install -c chou_uken biofkit
```
### Mamba
``` 
mamba install -c chou_uken biofkit
```

### Pip
```console
pip install biofkit
```

## How to Use
Documents will help you!
[中文文档](https://chou-uken.github.io/biofkit/chinese/)
Waiting for more languages...
